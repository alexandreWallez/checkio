def whichisgreater(x,y) :
    """
    https://open.kattis.com/problems/whichisgreater
    """
    if x > y :
        return 0
    else :
        return 1